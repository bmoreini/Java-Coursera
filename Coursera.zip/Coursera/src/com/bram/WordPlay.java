package com.bram;

import java.util.Iterator;

public class WordPlay {

    public static Boolean isVowel (Character ch) {


    }
}
